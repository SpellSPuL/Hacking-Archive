' This file is a republish of the original
' 1995-1997 of SPuL.BAS.
'
' The code has been removed from this version
' for safety reasons.
'
' Licensed under CC BY-NC-ND (Creative Commons 
' Attribution-NonCommercial-NoDerivatives)
'
' (c)1995-2026 SPuL 
'
'=========================================
'
'Hi, if download version 9 of this bas
'you may noticed it didn't work. That's
'because I made stupid mistake in the
'functions get_by_class and get_by_text
'these functions were required for allmost
'every other function in this bas. Anyway,
'I fixed them (and test them this time) and
'every works.. well except the examples
'I'm still working on those.
'
'
'
'
'      '   (     (   '    '  )     (
'      )   )) '  ))   (   ) ((   '  )
'     (   ( (_  ( (_  )) (( ) )' ) (
'        / ___\/ __ \/ \ / \| | ((
'     (  \__) \|  _(/| |_( || |_) ) )
'     ))_/ (( /| |_))\   ))/\  ( (_((
'    (_______________________________)
'
'     Sorry no greets,I know too many
'  people to remember all of you at once
'
'  *************************************
'  The code & theory in this file is for
'  learning purpuses only. Don't use it!
'  *************************************
'             �1995-1997 Spul
'
'*Spul's Intro
' Most of you don't remember me, that's ok, I didn't
' release that many programs and it was a while ago anyway.
' Now if you haven't guessed by my handle, my spulling and
' English suck. If don't like it... fuck off!
'
'*About
' Ok, now that that's over with lets move on to about
' the bas. I was hanging around VB one day helping people
' out (I've never needed much help, reading the VB help files
' was enough for me, but I bet it must suck when know one will
' answer an intellegent question). When someone asked me about
' a sub they had called "Hit_Menu_". Now, I worte a sub called
' "Hit_Menu_By_String" and my gut told me that it wasn't a
' coincidence that the names were so simular. But just to be
' sure, I asked asked the guy to send the sub to me. I was
' right, it was my original sub. The var names were even
' the same. (however I have changed the a bit in this version
' of my bas)
'
'*Well what does that mean to you, NOTHING! It's just my
' way of setting up what I'm going to say next;
'
'   I'm sick of people taking credit for my original
'   tricks and stealing my original code. I'm releasing
'   this bas so people know who wrote these subs and
'   so I get some credit.
'
' On that note, I want to give out a greetz to Anbuis for
' mentioning me on his version of the transfer control.
'
' I want also want Genozide some greets for corecting the
' credit in his bas.
'
'*What you won't find in this BAS file.
'
' You will not find all-in-one functions or subs like
' "Send_Mail" or "Run_Tool_Bar". I used to rewrite these
' Types of subs all time, impoving them as I gained more
' experiance. However, with the subs I've include,
' It should be very easy for you to code you're own calls
' like those. Trust me, you learn alot more when you struggle
' with somthing you're self.
'
' ahh.. ok, just to prove how easy an "all-in-one" sub is
' to write....
'
' [Code Removed]
'
'  Sub Hit_ToolBar_Button_By_Position(A25TB_Button_Pos)
'
' [Code Removed]
'
'  End sub
'
'  Hit_ToolBar_Button_By_Position(A25TB_ReadNewMail)
'
' I've also left out the my version of the get
' _AOL_ListBox items without a DLL. This was done because
' I don't want any programmers who write Email address
' harvesting software to get their slimy little hands
' on it.
'
'*If you use these subs as is I (Spul) expect some credit.
' You may not include any of these subs new BAS files.
' It's ok, to put it one for you're personal use. Just
' Don't realeas it. It's also ok to take out the rem statements
' out when you're. Just make sure you only send out a full
' commented copy of this bas.
'
'*Last thing, I didn't ask for anything when I gave you this
' bas, so don't trade it! If someone wants it, give it
' to them for free .. (or in AOLer Talk: 4 PhReE)
'
'*That's it, Have Fun,
' Spul
'
'*History
' -01 :First Release
' -02 :Corected some spelling
' -03 :Got durnk and added the Xlame functions
'      made some spulling mistakes =)
'      Even though these sub are just lame text
'      formating stuff You may wanna take a look at
'      them to pick up some tricks
' -04 :Fixed some spulling mistakes
' -05 :Changed some of API function calls to subs
'      (the ones that returned irrelevant information)
'     :Moved the Xlame functions to one sub called -
'      How_do_i_program_kewl_aol_stuff()
' -06 :Are you really still reading this?
'      Removed the Send_STMP_Mail sub
'      VB just doesn't do winsock api all that
'      well. I think I'm going to write a DLL to this
'      instead. Ahh.. not in vb of course.
' -07 :Ok, I'm bored with fixing this up, if you
'      don't like it, don't use it....Fist Public Release
' -08 :Ahh, found some major bugs base subs that screwed
'      whole bas up! now they're fixed.
'
'
' ************** Some API Subs **************
Declare Sub WritePrivateProfileString Lib "Kernel" (ByVal lpApplicationName As String, lpKeyName As Any, lpString As Any, ByVal lplFileName As String)
Declare Sub BitBlt Lib "GDI" (ByVal destDC%, ByVal x%, ByVal y%, ByVal w%, ByVal h%, ByVal srchDC%, ByVal srcX%, ByVal srcY%, ByVal rop&)
Declare Sub Setwindowpos Lib "User" (ByVal h1%, ByVal h2%, ByVal x%, ByVal y%, ByVal cx%, ByVal cy%, ByVal f%)
Declare Sub SetFocusAPI Lib "User" Alias "SetFocus" (ByVal hWnd As Integer)
Declare Sub sndPlaySound Lib "MMSystem" (lpsound As Any, ByVal flag As Integer)


' ************** User Decs **************
Declare Function GetClassname Lib "User" (ByVal hWnd As Integer, ByVal lpClassName As String, ByVal nMaxCount As Integer) As Integer
Declare Function GetMenu Lib "User" (ByVal hWnd As Integer) As Integer
Declare Function GetMenuItemID Lib "User" (ByVal hMenu As Integer, ByVal nPos As Integer) As Integer
Declare Function GetMenuString Lib "User" (ByVal hMenu As Integer, ByVal wIDItem As Integer, ByVal lpString As String, ByVal nMaxCount As Integer, ByVal wFlag As Integer) As Integer
Declare Function GetMenuItemCount Lib "User" (ByVal hMenu As Integer) As Integer
Declare Function GetSubMenu Lib "User" (ByVal hMenu As Integer, ByVal nPos As Integer) As Integer
Declare Function GettopWindow Lib "User" (ByVal hWnd As Integer) As Integer
Declare Function gettickcount Lib "User" () As Long
Declare Function GetWindow Lib "User" (ByVal hWnd As Integer, ByVal wCmd As Integer) As Integer
Declare Function Findwindow Lib "User" (ByVal lpClassName As Any, ByVal lpWindowName As Any) As Integer
Declare Function InsertMenu Lib "User" (ByVal hMenu As Integer, ByVal nPosition As Integer, ByVal wFlags As Integer, ByVal wIDNewItem As Integer, ByVal lpNewItem As Any) As Integer
Declare Function PostMessage Lib "User" (ByVal hWnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, lParam As Any) As Integer
Declare Function SendMessage Lib "User" (ByVal hWnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, lParam As Any) As Long
Declare Function sendmessagebynum Lib "User" Alias "SendMessage" (ByVal hWnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Long) As Integer
Declare Function sendmessagebystring& Lib "User" Alias "SendMessage" (ByVal hWnd%, ByVal wMsg%, ByVal wParam%, ByVal lParam$)

' ************** Kernel**************
Declare Function lstrcpy Lib "Kernel" (ByVal lpString1 As Any, ByVal lpString2 As Any) As Long
Declare Function lstrlen Lib "Kernel" (ByVal lpString As Any) As Integer
Declare Function GetPrivateProfileString Lib "Kernel" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Integer, ByVal lpFilename As String) As Integer
Declare Function GetModuleFileName Lib "Kernel" (ByVal hModule As Integer, ByVal lpFilename As String, ByVal nSize As Integer) As Integer
Declare Function GetModuleHandle Lib "Kernel" (ByVal lpModuleName As String) As Integer

' ************** Usefull stuff I didn't use in this Bas.
'Declare Function GetWindowsDirectory Lib "Kernel" (ByVal P$, ByVal S%) As Integer
'Declare Function GetSystemDirectory Lib "Kernel" (ByVal P$, ByVal S%) As Integer
'Declare Function GetDeskTopWindow Lib "User" () As Integer
'Declare Function GetParent Lib "User" (ByVal hWnd As Integer) As Integer
'Declare Function SetParent Lib "User" (ByVal hWndChild As Integer, ByVal hWndNewParent As Integer) As Integer
'Declare Function ShowWindow Lib "User" (ByVal hWnd As Integer, ByVal nCmdShow As Integer) As Integer
'Declare Sub hmemcpy Lib "Kernel" (lpDest As Any, lpSource As Any, ByVal nCount As Long)

' ************** Common addon dlls **************
'Declare Function aggetstringfromlpstr$ Lib "apiguide.dll" (ByVal lpString&)
'Declare Function aolgetlist% Lib "311.dll" (ByVal Index%, ByVal buf$)
'Declare Function aolgetcombo% Lib "311.dll" (ByVal Index%, ByVal buf$)
'Declare Function AolGettree% Lib "311.dll" (ByVal Index%, ByVal buf$)
'
' ************** Vbwfind.dll**************
Declare Function FindChildBytitle% Lib "vbwfind.dll" (ByVal parent%, ByVal Title$)
Declare Function FindChildByClass% Lib "vbwfind.dll" (ByVal parent%, ByVal Title$)

' ~~~~~~~~~~ Dims ~~~~~~~~~~~~~~

' ********** Misc
Global Const HWND_TOPMOST = -1

' ********** SWPs
Global Const SWP_NOSIZE = &H1
Global Const SWP_NOMOVE = &H2
Global Const SWP_NOZORDER = &H4
Global Const SWP_NOREDRAW = &H8
Global Const SWP_NOACTIVATE = &H10
Global Const SWP_DRAWFRAME = &H20
Global Const SWP_SHOWWINDOW = &H40
Global Const SWP_HIDEWINDOW = &H80
Global Const SWP_NOCOPYBITS = &H100
Global Const SWP_NOREPOSITION = &H200

' ********** scr
Global Const SRC_COPY = &HCC0020
Global Const SRCAND = &H8800C6
Global Const SRCPAINT = &HEE0086
Global Const NOTSRCCOPY = &H330008

' ********** MFs
Global Const MF_POPUP = &H10
Global Const MF_BYPOSITION = &H400
Global Const MF_SEPARATOR = &H800

' ********** WMs
Global Const WM_PARENTNOTIFY = &H210
Global Const WM_MDICREATE = &H220
Global Const WM_MDIDESTROY = &H221
Global Const WM_MDIACTIVATE = &H222
Global Const WM_MDIRESTORE = &H223
Global Const WM_MDINEXT = &H224
Global Const WM_MDIMAXIMIZE = &H225
Global Const WM_MDITILE = &H226
Global Const WM_MDICASCADE = &H227
Global Const WM_MDIICONARRANGE = &H228
Global Const WM_MDIGETACTIVE = &H229
Global Const WM_MDISETMENU = &H230
Global Const WM_CLEAR = &H303
Global Const WM_CUT = &H300
Global Const WM_SETTEXT = &HC
Global Const WM_GETTEXT = &HD
Global Const WM_SPUL = &H111
Global Const WM_USER = &H400
Global Const WM_PASTE = &H302
Global Const WM_LBUTTONDBLCLK = &H203
Global Const WM_LBUTTONDOWN = &H201
Global Const WM_LBUTTONUP = &H202
Global Const WM_CHAR = &H102
Global Const WM_KEYDOWN = &H100
Global Const WM_KEYUP = &H101

' ********** LBs  { Important the LBs Need to come after the WMs }
Global Const LB_GETCOUNT = (WM_USER + 12)
Global Const LB_GETSEL = (WM_USER + 8)
Global Const LB_SETSEL = (WM_USER + 6)
Global Const LB_SETCURSEL = (WM_USER + 7)
Global Const LB_GETTEXT = (WM_USER + 10)
Global Const LB_GETTEXTLEN = (WM_USER + 11)

' ******** Types *********

Type WINDOWPOS
    hWnd As Integer
    hwndInsertAfter As Integer
    x As Integer
    y As Integer
    cx As Integer
    cy As Integer
    flags As Integer
End Type

''' Global Constants for Seconds_To_Time_String
Global Const fmtClock = 0
Global Const fmtLong = 1
Global Const fmtSort = 2
Global Const fmtMilli = 4

'Any sub with an A_Lesson will be a help file not a really a sub
'
'**** Lstrcpy vs APIGuide.DLL
'
' I've seen alot people use the aggetstringfromlpstr$ function
' call from APIGuide. APIGuide has alot of garbage functions in
' it and this is one them. You call a a lstrcpy right from VB
' intsead of apiguides one. It does the *exact* same thing. So get
' rid of the extra dll.
'
' [Code Removed]
'
' Note: when you're trying this with VBmsg the lparam
' is not dimed (declared) as a long. That means you
' need to do something this to make it work.
'
' [Code Removed]
'
'*Spul's Bas
Sub A_Lesson_1 ()

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Sub

'Any sub with an A_Lesson will be a help file not a really a sub
'
'**** Getting the text from a chat room (VBMessag.VBX)
'
' First,
' Set VBmessage to intercept WM_SETTEXT messages.(Click on
' the message selector in the properties window)
'
' Next find you're chatroom and the _AOL_View.
' Then set the subclasshwnd properity to the _AOL_View's Hwnd
'
' [Code Removed]
'
' - or -
'
' [Code Removed]
'
' Now goto VBmessage's WindowMessage Event and get the text form the lparam
' with a lstrcpy. (see lesson 1)
'
' You can not call a sub form the Message event. It will lock up
' VB. Set up listbox/timer to process and respond to you're
' incoming text.
'
'*Spul's Bas
Sub A_Lesson_2 ()

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 
End Sub

'Any sub with an A_Lesson will be a help file not a really a sub
'
'***** Patching files
'
'*Any file stored on you're HD can be patched with VB. Reset user, PWS's
' and vb exe protectors are all examples of patching files.
'
' The basics patching are simple; You use the get/put command to read
' and overwrite existing file bytes. But before you open a file ask
' you're self what am I going do with it. Am I going to write data like,
' for set-up program. Or am I overwriting existing data, like for reset
' a username. After deciding that it's time to open file you're file
' with the open command.
'
'  Example:
'
'  open "filename" for binary access read #1         ''both read an write
'  open "filename" for binary access write as #1 ''just write it, or add to it.
'
'*Reading a file into memory is simple. All you need to do is 1) define
' a buffer and 2) use the get command to read the bytes from the open file.
' The 1 (not #1) in the example below, tells vb where to start reading.
' The length of you're buffer tells vb how many bytes to read from the file.
'
'  Example:
'
'  buffer$ = space$(lof(#1),chr$(32))
'  get #1,1,buffer$
'         |--strating at
'
'  IMPORTANT: If you're file is over 32k you need to keep track
'             of you're file position and loop it.
'
'
'*Writing to file is just as easy as reading one, except you use
' a put command, all you need to do it tell VB what and were
' to overwrite.
'
'  Example:
'
'  A=space(10,chr$(0)) + "adds this on to the end of an EXE"
'  Put #1,(lof(#1))+1, A
'           |--strating at
'
'  If you're adding something onto a program you should pad it a bit with
'  null chars.
'
'*Ok, now lets say you want to find something and overwrite it.
'
'  Example:
'
'  open "filename" for binary as #1                 'both read an write
'  buffer$ = space$(lof(#1))                        'defines the amount of text to read (this case the whole file).
'  a$ = "you're string!"                            'it needs to be a var for vb syntax
'  get #1,1,buffer$                                 'reads the file in memory
'  if instr("lookfor string", buff$) <> 0 then      'makes sure you're look for string is in the file.
'    put #1,instr("lookfor string", buff$), a$      'puts the string in and overwrites any existing bytes.
'  end if
'
'  Be sure the data you're replacing is the same length as the
'  data you're replacing it with.
'
'*Hex dump Example (a hex editor written in vb?):
'
' [Code Removed]
'
'*Spul's Bas
Sub A_Lesson_3 ()

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Sub

'Any sub with an A_Lesson will be a help file not a really a sub
'
'***** Decompiler Protection Programs
'
'The section shows some of my original tricks found in my exe protector.
'(HEX). Quite a few people used these tricks in other protecters but,
'I did it first =). I'm not claiming they copied my code
'cause it's real simple to write. It's just that I discovered the
'header trick back in the days when the warez rooms where called
'warez when other protecters were just messing up the form names.
'
'*Checking for a VB header
' Open the exe file access read and see if the first 25 bytes are
' equal to the string below.
'
'  Eaxmple:
'
' [Code Removed]
'
'*Destroying the VB header: To do this you need to open the EXE
' file and write null chars (or anything else) the from the 4 byte
' to the 26 byte.
'
' [Code Removed]
'
'*Blanking out a from object
' First look for form name in you're exe with the instr$ (lesson 3),
' Next look for the "form" byte order(see below).
' Finally overwrite evrything between, inculding the form and name/byte
' order with null chars.
'
' [Code Removed]
'
'*Spul's Bas
Sub A_Lesson_4 ()

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 
End Sub

'Any sub with an A_Lesson will be a help file not a really a sub
'
'***** Trogans (virus delivery)
'
' The problem with trojans are those virus scanners. Here's how
' get around them. Read the virus(or exe containing it) and write
' it out backwards, if you're cleaver enough you can tack it onto
' the end of you're exe.
'
' [Code Removed]
'
' Get it? now a virus scanner will go over the trojan.exe looking for
' you're virus' byte order, but it won't find it cause it's backwards!
'
' To release the virus simply write the file backwards again
' (now forward) and shell to it.
'
'*Spul's Bas
Sub A_Lesson_5 ()

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Sub

'Any sub with an A_Lesson will be a help file not a really a sub
'
'*****PWS detectors
'
'I've never seen or written a pws program. But my guess is that you can
'fool detectors by simply using the same tricks as you would with passwords.
'
' [Code Removed]
'
'This works fine for the ones that scan the AOL db for flash session
'passwords. If you're trying writing one that does a WM_GETTEXT on the
'the password combox box. You may wanna try doing a himemcpy or process
'aols treads instead. That's to get around subclassing dectors.
'
'
'
'*Spul's Bas
Sub A_Lesson_6 ()

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Sub

'Any sub with an A_Lesson will be a help file not a really a sub
'
'** Cyrptography
'
'Some one asked me to put an example of this in this bas.
'
'Cryptography usally uses bit shifting and a few other things
'VB won't do. Something VB cannot do. But like return
'EnumChildWindows you can get around this with some clever coding.
'
'Ok, What need to you want to do is get the ASCII value of a singal char
'in a string and change it with some math equation (algorythm).
'
' Example: (Very Simple, easy to crack)
'
' [Code Removed]
'
' [Code Removed]
'
'Get creative, maybe mix up the + and - depending if the
'placement is odd or even. Use the date as Key (that 10 in above).
'Just be sure not to limit the char range to 28..255
'
'Example: algorithm that changes you're password every mounth
'
'Better but not great
'Function get_password(password$) as string
'
' [Code Removed]
'
'msgbox = "the password for the mounth of " + format(now,"mm-yy") + "is " + bshift
'
'Get_password = password$
'
'End function
'
'See lesson 6 on how hide passwords.
'
Sub A_Lesson_7 ()

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Sub

' Centers a control on form form
'
' Example:
'
' Center_CF Picture1, Me
'
'
Sub Center_CF (Thecontrol As Control, MaiMForm As Form)
  Thecontrol.Move MaiMForm.Left + (MaiMForm.Width - Thecontrol.Width) / 2, MaiMForm.Top + (MaiMForm.Height - Thecontrol.Height) / 2.5
End Sub

' Centers a form on a form
'
' Example:
'
' Center_FS Me, Form2
'
'
Sub Center_FF (theform As Form, MaiMForm As Form)
    theform.Move MaiMForm.Left + (MaiMForm.Width - theform.Width) / 2, MaiMForm.Top + (MaiMForm.Height - theform.Height) / 2.5
End Sub

' Centers a form on a screen
'
' Example:
'
' Center_FS Me
'
'
Sub Center_FS (theform As Form)
    theform.Move (screen.Width - theform.Width) / 2, (screen.Height - theform.Height) / 2.5
End Sub

' Centers a line
'
' Example:
'
' If sent to a chatroom
'
' send_text_to_aol(Edit%,Center_line("centered",20))
'
'
Function Center_Line (strz$, MaxLen)

 If Int(Len(strz$) / 2) < MaxLen Then
  Center_Line = " " + String$(MaxLen - Int(Len(strz$) / 2), Chr$(160)) & strz
 Else
  Center_Line = strz$
 End If

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Function

' This one *WILL_NOT* work with AOL3, then again it
' wasn't around when I wrote this bas =)
'
' If you need one for AOL 3, just check for the welcome
' window text with a len and see if it more then like
' 11 chars long.
'
' Eample:
'  if check_for_logon = false then msgbox ("run AOL")
'
Function Check_For_Logon ()
    
' [Code Removed]

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Function

' This is used for animation. It takes part of a
' window and copies to another one. kinda like picclip.vbx
' but you need to define you're own cels.
'
' You can draw directly on a form if need by changing destination As
' Control to destination as form
'
'  Sub Clip_Box (destination As From, source As Control, dx, dy, DW, DH, SX, SY)
'
' Example:
'  clip picture1,picture2,50,50,20,20,10,10
'
'  What that does is it copies a box form picture 2 starting
'  from 10,10 to 30,30 (10+20,10+20) and copies it to
'  picture1 at 50,50 to 70,70 (50+20, 50+20).
'
'  This doesn't works with images but it will work with any object
'  with a hwnd properity, such as a label.
'
'  Notes: keep you're color map all the same and under 235/
'  I didn't make a DC compatible bitmap in this sub.
'
Sub clip_box (destination As Control, source As Control, dx, dy, DW, DH, SX, SY)

  destination.AutoRedraw = True
  source.AutoRedraw = True
  destination.PSet (-1, -1), 0
  BitBlt destination.hDC, dx, dy, DW, DH, source.hDC, SX, SY, SRC_COPY
  destination.AutoRedraw = False
  source.AutoRedraw = False

End Sub

' Returns the handle of the chatroom
'
' This works with both old and new chatroom style
' windows.
'
'About the code:
'
'The int(var * (- .000001)) will take any number from
'1 - 32,724 (i.e. integer) and mutate it to a -1 while
'0s remain unchanged.
'
'As opossed to:
'
' [Code Removed]
'
'
'Why use the math? Well Vb does math much faster then it
'would a bunch of if ... then logic. Pluse it makes you're
'the code look really Leet =)
'
'
Function find_chatroom () As Long

' [Code Removed]

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Function

'Returns AOL's path.
'
'AOL must be running. This has been tested with all
'versions of AOL up to 2.5. The modual name may
'deifferent with newer versions.
'
'You can use the WPS utility that comes with vb3 to
'look up modual names.
'
' [Code Removed]
'
Function Get_Aol_Path () As String

' [Code Removed]
 
' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Function

' Returns a handle of window by it's position and
' specific class.
'
' Example:
'
' like say you want to hit the attach button on the mail
' window,
'
' send% = Get_By_Class (mailwin%,"_AOL_Icon",3)
' VLeft_Click(send%)
'
' The position starts with a 1, it's not a 0 based index
'
' Last thing, this is not recursive sub. What you're looking
' for needs to be in the a child of the hwnd specifed.
' eg. You CAN NOT do this
'
' get_by_class(aolwin%,"_AOL_Static",1)
'
Function get_by_class (Fhand%, class$, Pos)

' [Code Removed]

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Function

' Returns a handle of window a with a string or sub sting in
' it text in it.
'
' I wrote this sub before I knew about (maybe, before it
' exisited) findchildbytitle in vbwfind.dll
'
' This returns the first window found matching the sub string
' lookfor$
'
' Example:
'
' [Code Removed]
'
Function Get_by_text (FT_hand%, lookfor$)

' [Code Removed]

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Function

' Ever seen runmenu? It sucks huh?
'
' Well this is the sub that started this bas. If you
' didn't read the intro, read this..
'
' This sub will click any menu item by any string or
' sub-string in that item.
'
' Example:
'
' Hit_Menu_By_String ("Keyword...")
' Hit_Menu_By_String ("Ctrl+k")
' Hit_Menu_By_String ("Sign Off")
'
Sub hit_menu_by_string (Mnu_str$)

' [Code Removed]

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Sub

'
' ThIs WiLl ScRooL a kewL AsCII WiTH yOU'Re PrOgRaM Name
' aNd ThE DaTe iNTo aN AoL ChAT RooM....
'
' eXaMPLe:
'  how_do_i_program_kewl_aol_stuff ("you're progie name","you're name")
'
'
' *If use this one !!!_DO NOT_!!! give me cridit for it, lol. - spul
'
Sub how_do_i_program_kewl_aol_stuff (cap$, Who$)
  
  ReDim line1(0 To 3) As String

  line1(0) = "i'm using" + cap$ + " by " + Who$
  line1(1) = "the Date is " + Format(Now, "mm/yy/dd" + " ")
  line1(2) = "the time is " + Format(Now, "mm:hh:ss" + " ")
  line1(3) = "kewl huh?"

  ''' LiKe THiS
  line1(0) = LCase(line1(0))
  orderof$ = "aeiou"
  For a = 1 To Len(line1(0))
   x = Mid$(line1(0), a, 1)
   If InStr(orderof$, x) Then x = Chr$(Asc(x) - 32)
   Mid$(line1(0), a, 1) = x
  Next a
  
  ''' likE thiS
  line1(1) = LCase(line1(1)) + "  "
  For a = 2 To Len(line1(1))
   x = Mid$(line1(1), a, 1)
    If Asc(x) = 32 Then
     If Asc(Mid$(line1(1), a - 1, 1)) >= 65 + 32 And Asc(Mid$(line1(1), a - 1, 1)) <= 97 + 32 Then Mid$(line1(1), a - 1, 1) = Chr$(Asc(Mid$(line1(1), a - 1, 1)) - 32)
    End If
  Next a

  ''' LiKe ThIs
  line1(2) = UCase(line1(2))
  For a = 1 To Len(line1(2))
   x = Mid$(line1(2), a, 1)
    If Asc(x) >= 65 And Asc(x) <= 97 Then
     If Int(a / 2) = a / 2 Then Mid$(line1(2), a, 1) = Chr$(Asc(x) + 32)
   End If
  Next a

  ''' L i k e T h i s
  For a = 1 To Len(line1(3))
   If Asc(Mid$(line1(3), a, 1)) <> 32 Then tline$ = tline$ + Mid$(line1(3), 1, 1) + " "
  Next a
  line1(3) = tline$

  ''' add KeWL ansi =)
  For a = 0 To 5
   rndz$ = rndz$ + Chr$(Int(Rnd(4) * 132) + 100)
  Next a
  
  For a = 0 To 3
   line1(a) = rndz$ + " " + line1(a) + " " + rndz$
  Next a

  ''' Send it to AOL
  cr% = find_chatroom()
  If cr% = 0 Then Exit Sub

  ed% = get_by_class(cr%, "_AOL_Edit", 1)
  
  For a = 0 To 2
   send_text_to_aol ed%, Center_Line(line1(a) + "", 20) ' the + "" will automatically convert it to a string
  Next a
  
  Wait (1.5)
   send_text_to_aol ed%, Center_Line(line1(3) + "", 20) ' the + "" will automatically convert it to a string

End Sub

' Stay on top function
'
' The Axis is just a placement.
' C = center form
' R = right conner
'
' Anything else will be the design position on the form
'
' Make sure to make set the forms visible properity to false
' to avoid filickering when loading
'
Sub On_top (MaiMForm As Form, Axis As String)
 
 Setwindowpos MaiMForm.hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE Or SWP_SHOWWINDOW
 
 Select Case Format$(Axis, ">")
    Case "C"
        Center_FS MaiMForm
    Case "R"
        MaiMForm.Move screen.Width - MaiMForm.Width - 60, 80
 End Select

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Sub

' Plays a sound
'
' Example:
'
' Play_sound (app.path & "\intro.wav")
' Play_sound ("c:\windows\welcome.wav")
'
Sub Play_Sound (The_sound As String)
    sndPlaySound ByVal CStr(The_sound), 1
End Sub

Function Read_Ini (cap$, ifn$, app$)

Junk_Str$ = String$(128, 0)
spul% = GetPrivateProfileString(cap$, ifn$, "", Junk_Str$, Len(Junk_Str$), app$)
Read_Ini = Left$(Junk_Str$, spul%)

End Function

'This sub takes seconds and formats them into a time string.
'
'Examples:
'
' label1.caption = "You have been on-line for " & Seconds_To_Time_String(Timer1 - LogonSec, fmtLong) & "."
' label1.caption = "You have been on-line for " & Seconds_To_Time_String((gettictcount() / 100) - LogonSec, fmtLong + fmtMilli) & "."
'
'
Function seconds_to_time_string (fmt As Integer, Insec) As String

' [Code Removed]

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.

End Function

' Ever wanted to mail a password with out using AOLs
' mailing system?
'
' Example:
'   Send_SMTP_Mail (somenet.com, yourename@com.com, message$)
'
Sub Send_SMTP_Mail (Server As String, MailTo As String, message As String)

' This sub has been removed because VB doesn't handle
' winsock api all that well.
'
' I've written both a 16 bit & 32 bit DLL to this (Ahh.. not in
' vb of course) it's call vfysck16.dll you'll find it if look hard
' enough.

End Sub

' Sends some text & the Return key to AOL. Can be used for Edits, RichCTRLs
' and window captions.
'
' Example:
'
' send_text_to_aol (Edit%,"You're Text")
'
Sub send_text_to_aol (hand%, Sender$)

' [Code Removed]

End Sub

' Simulates the pressing of the spacebar on you're keyboard.
'
' Example:
'
' VKey_Space (Button%)
'
Sub vkey_space (hand%)
    
' [Code Removed]

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Sub

' Silulates a left click of a mouse button.
'
' Example:
'
' VLeft_Click (Button%)
'
Sub VLeft_click (hand%)

' [Code Removed]

End Sub

' Simulates a Double click with left mouse button.
'
' Example:
'
' [Code Removed]
'
' It's beyond the scope of this file to explain how to get
' item heights and scroll box positions.
'
' ahh .. ok, but I'm too lazy to write the excat code
'
' [Code Removed]
'
'
Sub VLeft_DClick (hand%, x, y)
    
' [Code Removed]

End Sub

' Relpaces the stupid timeout sub that's around.
' It's about 10 times as fast (it's doesn't make
' vb to think as much so it's more accurate)
' so adjust it accordingly.
'
' This sub is required for other subs in this bas.
'
Sub Wait (wtime As Integer)

' [Code Removed]

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Sub

' Get's the class name of a window.
'
' This sub is required for other subs in this bas.
'
'
Function Win_Class (C_wind%)
  
' [Code Removed]

' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Function

' Get's the window text. It does a WM_GETTEXT wich works
' better then a Getwindowtext. A Getwindowtext calls a
' WM_GETTEXT anyway.
'
' This sub is required for other subs in this bas.
'
Function win_text (T_wind%)
    
' [Code Removed]
  
' If you use theses subs I (Spul) expect some credit.
' You may not include any of these subs in another BAS.
 

End Function

Sub Write_Ini (cap As String, INF As String, VALZ As String, app As String)
    
   WritePrivateProfileString ByVal (cap), ByVal (INF), ByVal (VALZ), ByVal (app)

End Sub

