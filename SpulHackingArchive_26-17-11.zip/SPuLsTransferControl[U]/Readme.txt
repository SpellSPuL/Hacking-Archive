Install:

Ok I didn't include all the VBXs and DLL's I used it souldn't be a problem.

How to Use it:

1) Start your transfer
2) Click on the AOL looking Button
3) Wait a few seconds and Click on the button with % 
   on it
4) Now Click the AOL button again

Get it?

Later SPuL
